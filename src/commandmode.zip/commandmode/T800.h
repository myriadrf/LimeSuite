/* --------------------------------------------------------------------------------------------
FILE:		T800.h
DESCRIPTION     Implementation of Quadrature Adaptive Digital Predistorter module, using memory polinomials
                IQ imbalance is considered
CONTENT:
AUTHOR:		Lime Microsystems LTD
DATE:		Jan 01, 2018
-------------------------------------------------------------------------------------------- */
using namespace std;
//#include <wx/string.h>
#include <string>

class T800 {
public:
    double xip, xqp; // Quadrature inputs
    double xi, xq; // Quadrature feedback signal
    double ypi, ypq; // Quadrature outputs
    double err, aerr, perr; // Errors
    // Constructors
    T800(int, int, int);
    T800(int, int, int, double, double, double, int);
    ~T800();
    // Parameters
public: // These can not be changed after contructor is called
    // to prevent memory leacking
    int n; // Memory order - number of taps in the filter
    int m; // Nonlinearity order - polynomial order
    int n2; // Memory order - number of taps in the filter
    int m2; // Nonlinearity order - polynomial order
    int nd; // Delay the input before error is calculated
public:
    //double range;
    double g; // The gain of the predistorter
    double lambda; // RLS/SGRAD weighting coefficient
    double alpha; // SGRAD adaptation step size
    int training; // Training algorithm flag
    bool sEnv; // Use squared envelope if true
    double am; // Amplitude of IO signals.
    // Used to normalise  error signal and envelopes
    int skip; // Start adaptation process after skip clock cycles
    int skiping;
    int updating;
    bool enlog;
    bool endc;
    bool enkonj;

    //wxString
    std::string fname; // Log file name
    std::string fname2; // Log file name

    enum {
        LU, GS, GRAD
    }; // Available training algorithms
    // LU = LU factorisation
    // GS = Gauss-Seidel
    // GRAD = Gradient descent
    void write_coeff();
    void reset_coeff();
    void write_error();
    void prepare();
    int update_offset();

    void reset_matrix();
    void init(int N, int M, int Nd, double G, double Lambda, double Am, int Skip, int M2, bool Endc, bool Enkonj);
    void release_memory();
    void always(double XIp, double XQp, double XI, double XQ, double YIp, double YQp, bool Yp_FPGA);
    void oeval(double XIp, double XQp, double XI, double XQ, double YIp, double YQp, bool Yp_FPGA);
    void start();
    void finish();
    int update_coeff(double range);

    double uI, uQ, yI, yQ;
    double uenv, ueps;
    double **a, **b; // The coefficients
    double **a_, **b_; // The novel coefficients
    double **c, **d; // The coefficients
    double **c_, **d_; // The novel coefficients
    double oi, oq;
    double oi_, oq_;
private:
    // Output evaluation
    double oi_ave, oq_ave;
    void train(); // RLS or gradient descent adaptation
    FILE *fp; // Log file
    FILE *fp2; // Log file

    double *dI_reg, *dQ_reg;  
    double *uI_reg, *uQ_reg;  
    double **xIe, **xIep; // Delay register matrices
    double **xQe, **xQep;
    double **A, *B;
    int *index;
    double **Ap, *Bp;

};
