/* --------------------------------------------------------------------------------------------
FILE:		T800.cpp
DESCRIPTION     Implementation of Quadrature Adaptive Digital Predistorter module, using memory polinomials
                IQ imbalance is considered
CONTENT:
AUTHOR:		Lime Microsystems LTD
DATE:		Jan 01, 2018
-------------------------------------------------------------------------------------------- */

#include "T800.h"
#include "nrc.h"
#include "math.h"
#include <iostream>

#ifndef __unix__
#define M_PI 3.141592654
#endif

// Constructors
// --------------------------------------------------------------------------------------------

T800::T800(int N, int M, int Nd) {
    n = N;
    m = M;
    nd = Nd;
    g = 1.0;
    lambda = 0.999;
    alpha = 0.1;
    training = LU;
    sEnv = true;
    am = (double) (1 << (14 - 1));
    skip = 0;
    n = N;
    m = M;
    n2 = N;
    m2 = 1;
    fname = ("T800_error.log");
    fname2 = ("T800_coeff.log");
    uI_reg = 0;
    uQ_reg = 0;
    dI_reg = 0;
    dQ_reg = 0;
    a = 0;
    b = 0;
    c = 0;
    d = 0;
    a_ = 0;
    b_ = 0;
    c_ = 0;
    d_ = 0;
    xIe = 0;
    xIep = 0;
    xQe = 0;
    xQep = 0;
    A = 0;
    B = 0;
    index = 0;
    Ap = 0;
    Bp = 0;
    fp = 0;
    fp2 = 0;
    oi = oq = 0.0;
    oi_ = oq_ = 0.0;
    err = 0.0;
    aerr = 0.0;
    perr = 0.0;
    skiping = -1;
    updating = -1;
    oi_ave = oq_ave = 0.0;
    enlog = false;
    endc = true;
    enkonj = true;
    ueps=0.01;
}

T800::T800(int N, int M, int Nd, double G,
        double Lambda, double Am, int Skip) {

    n = N; // memorija
    m = M; // nelinearnost
    n2 = N;
    m2 = 1;
    nd = Nd;
    g = G;
    lambda = Lambda;
    alpha = 0.1;
    training = LU;
    // squared envelope
    sEnv = true;
    //sEnv = false;
    am = Am;
    skip = Skip;
    fname = ("T800_error.log");
    fname2 = ("T800_coeff.log");
    uI_reg = 0;
    uQ_reg = 0;
    dI_reg = 0;
    dQ_reg = 0;
    a = 0;
    b = 0;
    c = 0;
    d = 0;
    a_ = 0;
    b_ = 0;
    c_ = 0;
    d_ = 0;
    xIe = 0;
    xIep = 0;
    xQe = 0;
    xQep = 0;
    A = 0;
    B = 0;
    index = 0;
    Ap = 0;
    Bp = 0;
    fp = 0;
    fp2 = 0;
    oi = oq = 0.0;
    oi_ = oq_ = 0.0;
    err = 0.0;
    aerr = 0.0;
    perr = 0.0;
    oi_ave = oq_ave = 0.0;
    skiping = -1;
    updating = -1;
    enlog = false;
    endc = true;
    enkonj = true;
    ueps=0.01;
}

// Destructor
// --------------------------------------------------------------------------------------------

void T800::release_memory() {
    if (nd != 0) {
        if (uI_reg) delete [] uI_reg;
        if (uQ_reg) delete [] uQ_reg;
        if (dI_reg) delete [] dI_reg;
        if (dQ_reg) delete [] dQ_reg;
        uI_reg = 0;
        uQ_reg = 0;
        dI_reg = 0;
        dQ_reg = 0;
    }

    // Polynomials
    if (a) nrc::free_matrix(a, 0, n, 0, m);
    if (b) nrc::free_matrix(b, 0, n, 0, m);
    if (a_) nrc::free_matrix(a_, 0, n, 0, m);
    if (b_) nrc::free_matrix(b_, 0, n, 0, m);
    if (c) nrc::free_matrix(c, 0, n2, 0, m2);
    if (d) nrc::free_matrix(d, 0, n2, 0, m2);
    if (c_) nrc::free_matrix(c_, 0, n2, 0, m2);
    if (d_) nrc::free_matrix(d_, 0, n2, 0, m2);
    int maxm = 0;
    int maxn = 0;
    if (n > n2) maxn = n;
    else maxn = n2;
    if (m > m2) maxm = m;
    else maxm = m2;
    if (xIe) nrc::free_matrix(xIe, 0, maxn, 0, maxm);
    if (xIep) nrc::free_matrix(xIep, 0, maxn, 0, maxm);
    if (xQe) nrc::free_matrix(xQe, 0, maxn, 0, maxm);
    if (xQep) nrc::free_matrix(xQep, 0, maxn, 0, maxm);
    // Linear system of equations
    if (A) nrc::free_matrix(A, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (Ap) nrc::free_matrix(Ap, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (B) nrc::free_vector(B, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (Bp) nrc::free_vector(Bp, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (index) nrc::free_ivector(index, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (fp) fclose(fp);
    if (fp2) fclose(fp2);
    a = 0;
    b = 0;
    a_ = 0;
    b_ = 0;
    c = 0;
    d = 0;
    c_ = 0;
    d_ = 0;
    oi_ = oq_ = 0.0;
    oi = oq = 0.0;
    xIe = 0;
    xIep = 0;
    xQe = 0;
    xQep = 0;
    A = 0;
    B = 0;
    index = 0;
    Ap = 0;
    Bp = 0;
    fp = 0;
    fp2 = 0;
    skiping = -1;
    updating = -1;
}


// Destructor
// --------------------------------------------------------------------------------------------

T800::~T800() {
    if (nd != 0) {
        if (uI_reg) delete [] uI_reg;
        if (uQ_reg) delete [] uQ_reg;
        if (dI_reg) delete [] dI_reg;
        if (dQ_reg) delete [] dQ_reg;
        uI_reg = 0;
        uQ_reg = 0;
        dI_reg = 0;
        dQ_reg = 0;
    }

    // Polynomials
    if (a) nrc::free_matrix(a, 0, n, 0, m);
    if (b) nrc::free_matrix(b, 0, n, 0, m);
    if (a_) nrc::free_matrix(a_, 0, n, 0, m);
    if (b_) nrc::free_matrix(b_, 0, n, 0, m);
    if (c) nrc::free_matrix(c, 0, n2, 0, m2);
    if (d) nrc::free_matrix(d, 0, n2, 0, m2);
    if (c_) nrc::free_matrix(c_, 0, n2, 0, m2);
    if (d_) nrc::free_matrix(d_, 0, n2, 0, m2);
    int maxm = 0;
    int maxn = 0;
    if (n > n2) maxn = n;
    else maxn = n2;
    if (m > m2) maxm = m;
    else maxm = m2;
    if (xIe) nrc::free_matrix(xIe, 0, maxn, 0, maxm);
    if (xIep) nrc::free_matrix(xIep, 0, maxn, 0, maxm);
    if (xQe) nrc::free_matrix(xQe, 0, maxn, 0, maxm);
    if (xQep) nrc::free_matrix(xQep, 0, maxn, 0, maxm);
    // Linear system of equations
    if (A) nrc::free_matrix(A, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (Ap) nrc::free_matrix(Ap, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (B) nrc::free_vector(B, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (Bp) nrc::free_vector(Bp, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (index) nrc::free_ivector(index, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    if (fp) fclose(fp);
    if (fp2) fclose(fp2);
    a = 0;
    b = 0;
    a_ = 0;
    b_ = 0;
    c = 0;
    d = 0;
    c_ = 0;
    d_ = 0;
    oi = oq = 0.0;
    oi_ = oq_ = 0.0;
    xIe = 0;
    xIep = 0;
    xQe = 0;
    xQep = 0;
    A = 0;
    B = 0;
    index = 0;
    Ap = 0;
    Bp = 0;
    fp = 0;
    fp2 = 0;
    skiping = -1;
    updating = -1;
}

void T800::reset_matrix() {

    for (int i = 1; i <= 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2; i++) {
        B[i] = Bp[i] = 0.0;
        index[i] = 0;
        for (int j = 1; j <= 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2; j++)
            A[i][j] = Ap[i][j] = 0.0;
    }
}

void T800::prepare() {

    int maxm = 0;
    int maxn = 0;
    if (n > n2) maxn = n;
    else maxn = n2;
    if (m > m2) maxm = m;
    else maxm = m2;

    for (int i = 0; i <= maxn; i++) {
        for (int j = 0; j <= maxm; j++) {
            xIe[i][j] = xIep[i][j] = 0.0;
            xQe[i][j] = xQep[i][j] = 0.0;
        }
    }
    if (nd != 0) {
        for (int k = 0; k < nd; k++) {
            dI_reg[k] = dQ_reg[k] = 0.0;
            uI_reg[k] = uQ_reg[k] = 0.0;
        }
    }
}

// --------------------------------------------------------------------------------------------

void T800::init(int N, int M, int Nd, double G, double Lambda, double Am, int Skip, int M2, bool Endc, bool Enkonj) {

    oi_ave = oq_ave = 0.0;
    n = N;
    m = M;
    n2 = N;
    m2 = M2;
    endc = Endc;
    nd = Nd;
    g = G;
    lambda = Lambda;
    alpha = 0.1;
    training = LU;
    sEnv = true; // squared envelope
    am = Am;
    skip = Skip;
    fname = ("T800_error.log");
    fname2 = ("T800_coeff.log");
    enkonj = Enkonj;
    // Delay registers
    if (nd != 0) {
        dI_reg = new double[nd];
        dQ_reg = new double[nd];
        uI_reg = new double[nd];
        uQ_reg = new double[nd];
        for (int k = 0; k < nd; k++) {
            dI_reg[k] = dQ_reg[k] = 0.0;
            uI_reg[k] = 0.0;
            uQ_reg[k] = 0.0;
        }
    }
    // Polynomials
    if (a == 0) a = nrc::matrix(0, n, 0, m);
    if (b == 0) b = nrc::matrix(0, n, 0, m);
    if (a_ == 0) a_ = nrc::matrix(0, n, 0, m);
    if (b_ == 0) b_ = nrc::matrix(0, n, 0, m);
    if (c == 0) c = nrc::matrix(0, n2, 0, m2);
    if (d == 0) d = nrc::matrix(0, n2, 0, m2);
    if (c_ == 0) c_ = nrc::matrix(0, n2, 0, m2);
    if (d_ == 0) d_ = nrc::matrix(0, n2, 0, m2);

    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            a[i][j] = b[i][j] = 0.0;
            a_[i][j] = b_[i][j] = 0.0; // novel
        }
    }
    a[0][0] = 1.0;
    a_[0][0] = 1.0; // novel
    oi = oq = 0.0;
    oi_ = oq_ = 0.0;

    for (int i = 0; i <= n2; i++) {
        for (int j = 0; j <= m2; j++) {
            c[i][j] = d[i][j] = 0.0;
            c_[i][j] = d_[i][j] = 0.0; // novel
        }
    }

    int maxm = 0;
    int maxn = 0;
    if (n > n2) maxn = n;
    else maxn = n2;
    if (m > m2) maxm = m;
    else maxm = m2;
    xIe = nrc::matrix(0, maxn, 0, maxm);
    xIep = nrc::matrix(0, maxn, 0, maxm);
    xQe = nrc::matrix(0, maxn, 0, maxm);
    xQep = nrc::matrix(0, maxn, 0, maxm);

    for (int i = 0; i <= maxn; i++) {
        for (int j = 0; j <= maxm; j++) {
            xIe[i][j] = xIep[i][j] = 0.0;
            xQe[i][j] = xQep[i][j] = 0.0;
        }
    }

    // Linear system of equations
    A = nrc::matrix(1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    Ap = nrc::matrix(1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, 1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    B = nrc::vector(1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    Bp = nrc::vector(1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
    index = nrc::ivector(1, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);

    for (int i = 1; i <= (2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2); i++) {
        B[i] = Bp[i] = 0.0;
        index[i] = 0;
        for (int j = 1; j <= (2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2); j++)
            A[i][j] = Ap[i][j] = 0.0;
    }

    skiping = -1;
    updating = -1;

    if (enlog) {
        if (fname.length() > 0) {
            fp = fopen(fname.c_str(), "w");
        }
        if (fp) {
            fprintf(fp, "# 'error' 'amplitude error' 'phase error'\n");
            fprintf(fp, "# ----------------------------------------------------\n");
        }

        if (fp) fclose(fp); //fp = NULL;

        if (fname2.length() > 0) {
            fp2 = fopen(fname2.c_str(), "w");
        }
        if (fp2) {
            fprintf(fp2, "\n# T800 coefficients:\n");
            fprintf(fp2, "# ----------------------------------------------------\n");
        }

        if (fp2) fclose(fp2); //fp2 = NULL;
        write_coeff();
    }
}

// --------------------------------------------------------------------------------------------

void T800::always(double XIp, double XQp, double XI, double XQ, double YIp, double YQp, bool Yp_FPGA) {
    // Evaluate the outputs
    oeval(XIp, XQp, XI, XQ, YIp, YQp, Yp_FPGA);

    //std::cout << "skiping"<< skiping << "updating"<< updating <<std::endl;
    if (skiping == 0) train();

    if (skiping > 0) skiping--;
    else if (skiping == 0) {
        skiping = 0;
        //std::cout << "skiping"<< skiping << "updating"<< updating <<std::endl;

        if (updating > 0) {
            updating--;
        } else if (updating == 0) {
            //std::cout << "Print the coefficients"<< std::endl;
            write_coeff();
            write_error();
            updating = -1;
            skiping = -1;
        }
    }
}

// --------------------------------------------------------------------------------------------

void T800::write_coeff() {

    if (enlog) {
        // Print the coefficients
        fname2 = ("T800_coeff.log");
        if (fname2.length() > 0) {
            fp2 = fopen(fname2.c_str(), "a");
        }
        if (fp2 == NULL) return;

        for (int i = 0; i <= n; i++) {
            fprintf(fp2, "# i = %d, a[%d][] = ", i, i);
            for (int j = 0; j <= m; j++) {
                fprintf(fp2, "%lg, ", a_[i][j]);
            }
            fprintf(fp2, "\n");
        }

        fprintf(fp2, "\n");
        for (int i = 0; i <= n; i++) {
            fprintf(fp2, "# i = %d, b[%d][] = ", i, i);
            for (int j = 0; j <= m; j++) {
                fprintf(fp2, "%lg, ", b_[i][j]);
            }
            fprintf(fp2, "\n");
        }
        if (enkonj) {
            fprintf(fp2, "\n");
            for (int i = 0; i <= n2; i++) {
                fprintf(fp2, "# i = %d, c[%d][] = ", i, i);
                for (int j = 0; j <= m2; j++) {
                    fprintf(fp2, "%lg, ", c_[i][j]);
                }
                fprintf(fp2, "\n");
            }

            fprintf(fp2, "\n");
            for (int i = 0; i <= n2; i++) {
                fprintf(fp2, "# i = %d, d[%d][] = ", i, i);
                for (int j = 0; j <= m2; j++) {
                    fprintf(fp2, "%lg, ", d_[i][j]);
                }
                fprintf(fp2, "\n");
            }
        }
        if ((endc)&&(enkonj)) {
            fprintf(fp2, "# oi, oq = ");
            fprintf(fp2, "%lg, ", oi);
            fprintf(fp2, "%lg, ", oq);
            fprintf(fp2, "\n");
        }

        fprintf(fp2, "\n");
        if (fp2) fclose(fp2);
        fp2 = NULL;
    }
}

void T800::write_error() {

    // Print the coefficients
    if (enlog) {

        fname = ("T800_error.log");
        if (fname.length() > 0) {
            fp = fopen(fname.c_str(), "a");
        }

        if (fp == NULL) return;
        fprintf(fp, "%lg %lg %lg\n", err, aerr, perr);

        if (fp) fclose(fp);
        fp = NULL;
    }
}

void T800::start() {
    if (enlog) {
        //fname = ("T800_error.log");
        //if (fname.length() > 0) {
        //	fp = fopen(fname.c_str(), "a");
        //}
    }
}

// --------------------------------------------------------------------------------------------

void T800::finish() {
    if (enlog) {
        //if (fp) fclose(fp);
        //fp = NULL;
    }
}

// --------------------------------------------------------------------------------------------
// Output evaluation
// --------------------------------------------------------------------------------------------

void T800::oeval(double XIp, double XQp, double XId, double XQd, double YIp, double YQp, bool Yp_FPGA) {
    double XI, XQ;
    double YpI, YpQ;
    double e, ep; // Envelopes
    double dI, dQ; // Delayed xp
    // no necessary
    oi_ave = oi_ave * 0.8 + oi * am * 0.2;
    oq_ave = oq_ave * 0.8 + oq * am * 0.2;

    if (endc) {
        //XI  =  XId-oi_ave;
        //XQ  =  XQd-oq_ave;
        //XI  =  XId-oi*am;
        //XQ  =  XQd-oq*am;
        XI = XId;
        XQ = XQd;
    }
    else {
        XI = XId;
        XQ = XQd;
    }

    // Envelopes
    e = XI * XI + XQ*XQ;
    e /= am*am;
    if (sEnv == false) e = sqrt(e);
    ep = XIp * XIp + XQp*XQp;
    ep /= am*am;
    if (sEnv == false) ep = sqrt(ep);

    // Update delay register matrices
    int maxm = 0;
    int maxn = 0;
    if (n > n2) maxn = n;
    else maxn = n2;
    if (m > m2) maxm = m;
    else maxm = m2;

    for (int i = maxn; i > 0; i--) {
        for (int j = 0; j <= maxm; j++) {
            xIe[i][j] = xIe[i - 1][j];
            xIep[i][j] = xIep[i - 1][j];
            xQe[i][j] = xQe[i - 1][j];
            xQep[i][j] = xQep[i - 1][j];
        }
    }
    xIe[0][0] = XI;
    xIep[0][0] = XIp;
    xQe[0][0] = XQ;
    xQep[0][0] = XQp;

    for (int j = 1; j <= maxm; j++) {
        xIe[0][j] = xIe[0][j - 1] * e;
        xIep[0][j] = xIep[0][j - 1] * ep;
        xQe[0][j] = xQe[0][j - 1] * e;
        xQep[0][j] = xQep[0][j - 1] * ep;
    }

    // MPOLY outputs
    // Yp = y = 0;
    //ypi = 0;
    //ypq = 0;

    YpI = YpQ = yI = yQ = 0;
    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            yI += (a[i][j]) * xIe[i][j] - (b[i][j]) * xQe[i][j];
            yQ += (a[i][j]) * xQe[i][j] + (b[i][j]) * xIe[i][j];
            YpI += (a[i][j]) * xIep[i][j] - (b[i][j]) * xQep[i][j];
            YpQ += (a[i][j]) * xQep[i][j] + (b[i][j]) * xIep[i][j];
        }
    }

    if (enkonj) {
        for (int i = 0; i <= n2; i++) {
            for (int j = 0; j <= m2; j++) {
                yI += (c[i][j]) * xIe[i][j] + (d[i][j]) * xQe[i][j];
                yQ += (-c[i][j]) * xQe[i][j] + (d[i][j]) * xIe[i][j];
                YpI += (c[i][j]) * xIep[i][j] + (d[i][j]) * xQep[i][j];
                YpQ += (-c[i][j]) * xQep[i][j] + (d[i][j]) * xIep[i][j];
            }
        }
    }

    if ((endc)&&(enkonj)) {
        yI += oi*am;
        yQ += oq*am;
        YpI += oi*am; // ovo nigde ne ide
        YpQ += oq*am; // samo za racunanje greske
    }

    if (yI > (am - 1)) yI = (am - 1);
    if (yI < (0 - am)) yI = (0 - am);
    if (yQ > (am - 1)) yQ = (am - 1);
    if (yQ < (0 - am)) yQ = (0 - am);

    // MPOLY outputs
    ypi = 0;
    ypq = 0;

    double YpI_ = 0;
    double YpQ_ = 0;

    // from FPGA
    // YIp  += oi_ave; //oi*am; //
    // YQp  += oq_ave; //oq*am; //;
    if (Yp_FPGA == true) {
        ypi = (g * YIp); // from FPGA
        ypq = (g * YQp);
        YpI_ = (YIp); //  * g
        YpQ_ = (YQp); //  * g
    } else {
        ypi = (g * YpI); // from control software
        ypq = (g * YpQ);
        YpI_ = YpI;
        YpQ_ = YpQ;
    }

    // Delays
    if (nd == 0) {
        dI = XIp;
        dQ = XQp;
        uI = YpI;
        uQ = YpQ;
    } else {
        dI = dI_reg[nd - 1];
        for (int k = nd - 1; k >= 1; k--) dI_reg[k] = dI_reg[k - 1];
        dI_reg[0] = XIp;
        dQ = dQ_reg[nd - 1];
        for (int k = nd - 1; k >= 1; k--) dQ_reg[k] = dQ_reg[k - 1];
        dQ_reg[0] = XQp;
        uI = uI_reg[nd - 1];
        for (int k = nd - 1; k >= 1; k--) uI_reg[k] = uI_reg[k - 1];
        uI_reg[0] = YpI_; // from FPGA
        uQ = uQ_reg[nd - 1];
        for (int k = nd - 1; k >= 1; k--) uQ_reg[k] = uQ_reg[k - 1];
        uQ_reg[0] = YpQ_;
    }

    err = fabs(sqrt((yI - uI)*(yI - uI) + (yQ - uQ)*(yQ - uQ))) / am;
    aerr = fabs(sqrt(XI * XI + XQ * XQ) - sqrt(dI * dI + dQ * dQ)) / am;
    perr = 180.0 * atan2(-XI * dQ + XQ*dI, XI * dI + XQ * dQ) / M_PI;


    uenv = fabs(sqrt(uI*uI + uQ*uQ)) / am; // normalized envelope




}

int T800::update_offset() {


    double oi1 = 0.0;
    double oq1 = 0.0;
    double eps = 0.002;
    int temp = 0;


    /////////////////
    if ((endc)&&(enkonj)) {
        oi1 = oi_;
        oq1 = oq_;

        if (oi1 > 1.0) {
            oi1 = (1.0 - eps);
            temp = -1;
        }
        if (oi1 < (-1.0)) {
            oi1 = (-1.0 + eps);
            temp = -1;
        }
        if (oq1 > 1.0) {
            oq1 = 1.0 - eps;
            temp = -1;
        }
        if (oq1 < (-1.0)) {
            oq1 = (-1.0 + eps);
            temp = -1;
        }
        oi = oi1;
        oq = oq1;
    }
    /////////////////
    return temp;

}

int T800::update_coeff(double range) {

    double a1 = 0.0;
    double b1 = 0.0;
    double c1 = 0.0;
    double d1 = 0.0;
    double oi1 = 0.0;
    double oq1 = 0.0;

    double eps = 0.001;
    int temp = 0;

    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {

            a1 = a_[i][j];
            b1 = b_[i][j];

            if (a1 >= range) {
                a1 = (range - eps);
                temp = -1;
            }
            if (a1 <= (-range)) {
                a1 = (-range + eps);
                temp = -1;
            }
            if (b1 >= range) {
                b1 = range - eps;
                temp = -1;
            }
            if (b1 <= (-range)) {
                b1 = (-range + eps);
                temp = -1;
            }

            a[i][j] = a1;
            b[i][j] = b1;
        }
    }

    if (enkonj) {
        for (int i = 0; i <= n2; i++) {
            for (int j = 0; j <= m2; j++) {

                c1 = c_[i][j];
                d1 = d_[i][j];

                if (c1 >= range) {
                    c1 = (range - eps);
                    temp = -1;
                }
                if (c1 <= (-range)) {
                    c1 = (-range + eps);
                    temp = -1;
                }
                if (d1 >= range) {
                    d1 = range - eps;
                    temp = -1;
                }
                if (d1 <= (-range)) {
                    d1 = (-range + eps);
                    temp = -1;
                }

                c[i][j] = c1;
                d[i][j] = d1;
            }
        }
    }

    /////////////////
    if ((endc)&&(enkonj)) {
        oi1 = oi_;
        oq1 = oq_;

        if (oi1 >= 1.0) {
            oi1 = (1.0 - eps);
            temp = -1;
        }
        if (oi1 <= (-1.0)) {
            oi1 = (-1.0 + eps);
            temp = -1;
        }
        if (oq1 >= 1.0) {
            oq1 = 1.0 - eps;
            temp = -1;
        }
        if (oq1 <= (-1.0)) {
            oq1 = (-1.0 + eps);
            temp = -1;
        }
        oi = oi1;
        oq = oq1;
    }
    /////////////////

    return temp;
}

void T800::reset_coeff() {

    int maxm = 0;
    int maxn = 0;

    if (n > n2) maxn = n;
    else maxn = n2;

    if (m > m2) maxm = m;
    else maxm = m2;

    for (int i = 0; i <= maxn; i++) {
        for (int j = 0; j <= maxm; j++) {
            xIe[i][j] = xIep[i][j] = 0.0;
            xQe[i][j] = xQep[i][j] = 0.0;
        }
    }

    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            a[i][j] = b[i][j] = 0.0;
            a_[i][j] = b_[i][j] = 0.0; //novel
        }
    }

    a[0][0] = 1.0;
    a_[0][0] = 1.0; //novel

    oi = oq = 0.0;
    oi_ = oq_ = 0.0;

    for (int i = 0; i <= n2; i++) {
        for (int j = 0; j <= m2; j++) {
            c[i][j] = d[i][j] = 0.0;
            c_[i][j] = d_[i][j] = 0.0; //novel
        }
    }
}


// --------------------------------------------------------------------------------------------
// Recursive Least Squares
// --------------------------------------------------------------------------------------------

void T800::train() {

    int ij, kl;
    double dd;
    int offset = 0;
    int offsetj = 0;
    int offseti = 0;

    double lambda1=lambda;

    if(uenv<ueps) return; //lambda1=0.99999999;

    for (int k = 0; k <= n; k++) {
        for (int l = 0; l <= m; l++) {
            kl = k + (n + 1) * l;

            offset = 0;
            Bp[1 + kl + offset] = lambda1 * Bp[1 + kl + offset] + uI * xIe[k][l] / am / am + uQ * xQe[k][l] / am / am; // a
            B [1 + kl + offset] = Bp[1 + kl + offset];

            offset = (n + 1)*(m + 1);
            Bp[1 + kl + offset] = lambda1 * Bp[1 + kl + offset] - uI * xQe[k][l] / am / am + uQ * xIe[k][l] / am / am; // b
            B [1 + kl + offset] = Bp[1 + kl + offset];

            for (int i = 0; i <= n; i++) {
                for (int j = 0; j <= m; j++) {
                    ij = i + (n + 1) * j;

                    offseti = 0;
                    offsetj = 0; ///// a[k][l]	  
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + ///// a[i][j]
                            xIe[i][j] * xIe[k][l] / am / am + xQe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = 0;
                    offsetj = (n + 1)*(m + 1);
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] - xQe[i][j] * xIe[k][l] / am / am ///// b[i][j]
                            + xIe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = (n + 1)*(m + 1);
                    offsetj = 0; ///// b[k][l]
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + ///// a[i][j]
                            xQe[i][j] * xIe[k][l] / am / am - xIe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = (n + 1)*(m + 1);
                    offsetj = (n + 1)*(m + 1);
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am //// b[i][j]
                            + xQe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];
                }
            }

            for (int i = 0; i <= n2; i++) {
                for (int j = 0; j <= m2; j++) {
                    ij = i + (n2 + 1) * j;

                    offseti = 0;
                    offsetj = 2 * (n + 1)*(m + 1); ///// a[k][l]
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am //// c[i][j]
                            - xQe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = 0;
                    offsetj = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xQe[i][j] * xIe[k][l] / am / am //// d[i][j]
                            + xIe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = (n + 1)*(m + 1);
                    offsetj = 2 * (n + 1)*(m + 1); ///// b[k][l]
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] - xQe[i][j] * xIe[k][l] / am / am //// c[i][j]
                            - xIe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                    offseti = (n + 1)*(m + 1);
                    offsetj = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                    Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am //// d[i][j]
                            - xQe[i][j] * xQe[k][l] / am / am;
                    A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];
                }
            }
        }
    }


    if (enkonj) {
        for (int k = 0; k <= n2; k++) {
            for (int l = 0; l <= m2; l++) {

                kl = k + (n2 + 1) * l;
                offset = 2 * (n + 1)*(m + 1);
                Bp[1 + kl + offset] = lambda1 * Bp[1 + kl + offset] + uI * xIe[k][l] / am / am - uQ * xQe[k][l] / am / am; // c
                B [1 + kl + offset] = Bp[1 + kl + offset];

                offset = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                Bp[1 + kl + offset] = lambda1 * Bp[1 + kl + offset] + uI * xQe[k][l] / am / am + uQ * xIe[k][l] / am / am; // d
                B [1 + kl + offset] = Bp[1 + kl + offset];

                for (int i = 0; i <= n; i++) {
                    for (int j = 0; j <= m; j++) {
                        ij = i + (n + 1) * j;

                        offseti = 2 * (n + 1)*(m + 1);
                        offsetj = 0; ///// c[k][l]		
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + ///// a[i][j]
                                xIe[i][j] * xIe[k][l] / am / am - xQe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1);
                        offsetj = (n + 1)*(m + 1);
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] - xQe[i][j] * xIe[k][l] / am / am ///// b[i][j]
                                - xIe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        offsetj = 0; ///// d[k][l]
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + ///// a[i][j]
                                xQe[i][j] * xIe[k][l] / am / am + xIe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        offsetj = (n + 1)*(m + 1);
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am ///// b[i][j]
                                - xQe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];
                    }
                }

                for (int i = 0; i <= n2; i++) {
                    for (int j = 0; j <= m2; j++) {

                        ij = i + (n2 + 1) * j;

                        offseti = 2 * (n + 1)*(m + 1);
                        offsetj = 2 * (n + 1)*(m + 1); /////	  c[k][l]	
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am ///// c[i][j]
                                + xQe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1);
                        offsetj = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xQe[i][j] * xIe[k][l] / am / am ///// d[i][j]
                                - xIe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        offsetj = 2 * (n + 1)*(m + 1); /////	d[k][l]
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] - xQe[i][j] * xIe[k][l] / am / am ///// c[i][j]
                                + xIe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];

                        offseti = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        offsetj = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                        Ap[1 + kl + offseti][1 + ij + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + ij + offsetj] + xIe[i][j] * xIe[k][l] / am / am ///// d[i][j]
                                + xQe[i][j] * xQe[k][l] / am / am;
                        A [1 + kl + offseti][1 + ij + offsetj] = Ap[1 + kl + offseti][1 + ij + offsetj];
                    }
                }
            }
        }
    } // if (enkonj)

    //// DC offset
    if ((endc)&&(enkonj)) {
        for (int k = 0; k <= n; k++) {
            for (int l = 0; l <= m; l++) {

                kl = k + (n + 1) * l;
                offseti = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                offsetj = 0;
                Ap[1 + offseti][1 + kl + offsetj] = lambda1 * Ap[1 + offseti][1 + kl + offsetj] + xIe[k][l] / am;
                A[1 + offseti][1 + kl + offsetj] = Ap[1 + offseti][1 + kl + offsetj];

                Ap[1 + offseti + 1][1 + kl + offsetj] = lambda1 * Ap[1 + offseti + 1][1 + kl + offsetj] + xQe[k][l] / am;
                A[1 + offseti + 1][1 + kl + offsetj] = Ap[1 + offseti + 1][1 + kl + offsetj];

                offseti = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                offsetj = (n + 1)*(m + 1);
                Ap[1 + offseti][1 + kl + offsetj] = lambda1 * Ap[1 + offseti][1 + kl + offsetj] - xQe[k][l] / am;
                A[1 + offseti][1 + kl + offsetj] = Ap[1 + offseti][1 + kl + offsetj];

                Ap[1 + offseti + 1][1 + kl + offsetj] = lambda1 * Ap[1 + offseti + 1][1 + kl + offsetj] + xIe[k][l] / am;
                A[1 + offseti + 1][1 + kl + offsetj] = Ap[1 + offseti + 1][1 + kl + offsetj];

                offseti = 0;
                offsetj = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                Ap[1 + kl + offseti][1 + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + offsetj] + xIe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj] = Ap[1 + kl + offseti][1 + offsetj];

                Ap[1 + kl + offseti][1 + offsetj + 1] = lambda1 * Ap[1 + kl + offseti][1 + offsetj + 1] + xQe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj + 1] = Ap[1 + kl + offseti][1 + offsetj + 1];

                offseti = (n + 1)*(m + 1);
                offsetj = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                Ap[1 + kl + offseti][1 + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + offsetj] - xQe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj] = Ap[1 + kl + offseti][1 + offsetj];

                Ap[1 + kl + offseti][1 + offsetj + 1] = lambda1 * Ap[1 + kl + offseti][1 + offsetj + 1] + xIe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj + 1] = Ap[1 + kl + offseti][1 + offsetj + 1];

            }
        }
        for (int k = 0; k <= n2; k++) {
            for (int l = 0; l <= m2; l++) {

                kl = k + (n2 + 1) * l;

                offseti = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                offsetj = 2 * (n + 1)*(m + 1);
                Ap[1 + offseti][1 + kl + offsetj] = lambda1 * Ap[1 + offseti][1 + kl + offsetj] + xIe[k][l] / am;
                A[1 + offseti][1 + kl + offsetj] = Ap[1 + offseti][1 + kl + offsetj];
                Ap[1 + offseti + 1][1 + kl + offsetj] = lambda1 * Ap[1 + offseti + 1][1 + kl + offsetj] - xQe[k][l] / am;
                A[1 + offseti + 1][1 + kl + offsetj] = Ap[1 + offseti + 1][1 + kl + offsetj];

                offseti = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                offsetj = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                Ap[1 + offseti][1 + kl + offsetj] = lambda1 * Ap[1 + offseti][1 + kl + offsetj] + xQe[k][l] / am;
                A[1 + offseti][1 + kl + offsetj] = Ap[1 + offseti][1 + kl + offsetj];
                Ap[1 + offseti + 1][1 + kl + offsetj] = lambda1 * Ap[1 + offseti + 1][1 + kl + offsetj] + xIe[k][l] / am;
                A[1 + offseti + 1][1 + kl + offsetj] = Ap[1 + offseti + 1][1 + kl + offsetj];

                offseti = 2 * (n + 1)*(m + 1);
                offsetj = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                Ap[1 + kl + offseti][1 + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + offsetj] + xIe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj] = Ap[1 + kl + offseti][1 + offsetj];
                Ap[1 + kl + offseti][1 + offsetj + 1] = lambda1 * Ap[1 + kl + offseti][1 + offsetj + 1] - xQe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj + 1] = Ap[1 + kl + offseti][1 + offsetj + 1];

                offseti = 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1);
                offsetj = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
                Ap[1 + kl + offseti][1 + offsetj] = lambda1 * Ap[1 + kl + offseti][1 + offsetj] + xQe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj] = Ap[1 + kl + offseti][1 + offsetj];
                Ap[1 + kl + offseti][1 + offsetj + 1] = lambda1 * Ap[1 + kl + offseti][1 + offsetj + 1] + xIe[k][l] / am;
                A[1 + kl + offseti][1 + offsetj + 1] = Ap[1 + kl + offseti][1 + offsetj + 1];

            }
        }

        offseti = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);
        offsetj = 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1);

        Ap[1 + offseti][1 + offsetj] = lambda1 * Ap[1 + offseti][1 + offsetj] + 1.0;
        A[1 + offseti][1 + offsetj] = Ap[1 + offseti][1 + offsetj];
        Ap[1 + offseti + 1][1 + offsetj] = lambda1 * Ap[1 + offseti + 1][1 + offsetj] + 0.0;
        A[1 + offseti + 1][1 + offsetj] = Ap[1 + offseti + 1][1 + offsetj];
        Ap[1 + offseti][1 + offsetj + 1] = lambda1 * Ap[1 + offseti][1 + offsetj + 1] + 0.0;
        A[1 + offseti][1 + offsetj + 1] = Ap[1 + offseti][1 + offsetj + 1];
        Ap[1 + offseti + 1][1 + offsetj + 1] = lambda1 * Ap[1 + offseti + 1][1 + offsetj + 1] + 1.0;
        A[1 + offseti + 1][1 + offsetj + 1] = Ap[1 + offseti + 1][1 + offsetj + 1];

        Bp[1 + offseti] = lambda1 * Bp[1 + offseti] + uI / am; // c
        B[1 + offseti] = Bp[1 + offseti];
        Bp[1 + offseti + 1] = lambda1 * Bp[1 + offseti + 1] + uQ / am; // c
        B[1 + offseti + 1] = Bp[1 + offseti + 1];

    } // if (endc) 

    //update ++;

    if (updating == 0) {
        if (training == LU) {

            if ((endc)&&(enkonj)) {
                nrc::ludcmp(A, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, index, &dd);
                nrc::lubksb(A, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, index, B);
            }
            else if (enkonj) {
                nrc::ludcmp(A, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1), index, &dd);
                nrc::lubksb(A, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1), index, B);
            }
            else {
                nrc::ludcmp(A, 2 * (n + 1)*(m + 1), index, &dd);
                nrc::lubksb(A, 2 * (n + 1)*(m + 1), index, B);
            }
        }
        else {

            for (int i = 0; i <= n; i++) {
                for (int j = 0; j <= m; j++) {
                    B[1 + i + (n + 1) * j] = a[i][j];
                    B[1 + i + (n + 1) * j + (n + 1)*(m + 1)] = b[i][j];
                }
            }

            if (enkonj) {
                for (int i = 0; i <= n2; i++) {
                    for (int j = 0; j <= m2; j++) {
                        B[1 + i + (n2 + 1) * j + 2 * (n + 1)*(m + 1)] = c[i][j];
                        B[1 + i + (n2 + 1) * j + 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1)] = d[i][j];
                    }
                }
            }
            if ((endc)&&(enkonj)) {
                B[1 + 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1)] = oi;
                B[1 + 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 1] = oq;
            }


            if ((endc)&&(enkonj)) {
                if (training == GRAD) nrc::lgrad(A, Bp, B, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2, alpha);
                else if (training == GS) nrc::gauss_seidel(A, Bp, B, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 2);
            }
            else if (enkonj) {
                if (training == GRAD) nrc::lgrad(A, Bp, B, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1), alpha);
                else if (training == GS) nrc::gauss_seidel(A, Bp, B, 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1));
            } else {
                if (training == GRAD) nrc::lgrad(A, Bp, B, 2 * (n + 1)*(m + 1), alpha);
                else if (training == GS) nrc::gauss_seidel(A, Bp, B, 2 * (n + 1)*(m + 1));
            }
        } //else {


        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= m; j++) {
                a_[i][j] = B[1 + i + (n + 1) * j]; //novel
                b_[i][j] = B[1 + i + (n + 1) * j + (n + 1)*(m + 1)]; //novel
            }
        }

        if (enkonj) {
            for (int i = 0; i <= n2; i++) {
                for (int j = 0; j <= m2; j++) {
                    c_[i][j] = B[1 + i + (n2 + 1) * j + 2 * (n + 1)*(m + 1)]; //novel
                    d_[i][j] = B[1 + i + (n2 + 1) * j + 2 * (n + 1)*(m + 1)+(n2 + 1)*(m2 + 1)]; //novel
                }
            }
        } else {
            for (int i = 0; i <= n2; i++) {
                for (int j = 0; j <= m2; j++) {
                    c_[i][j] = 0.0;
                    d_[i][j] = 0.0;
                }
            }
        } // else {	

        if ((endc)&&(enkonj)) {
            oi_ = B[1 + 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1)];
            oq_ = B[1 + 2 * (n + 1)*(m + 1) + 2 * (n2 + 1)*(m2 + 1) + 1];
        }
        else {
            oi_ = 0.0;
            oq_ = 0.0;
        }

    }
}
