/**
    @file   basicRX.cpp
    @author Lime Microsystems (www.limemicro.com)
    @brief  minimal RX example
 */

#include <cstdlib>
#include "./../lime/LimeSuite.h"
#include <iostream>
#include "math.h"
#include <thread>
#include <chrono>

#ifdef USE_GNU_PLOT
#include "gnuPlotPipe.h"
#endif


#include "DPDcomm.h"
#include "CFRcomm.h"

using namespace std;

//Device structure, should be initialize to NULL
lms_device_t* device = NULL;

int error()
{
    //print last error message
    cout << "ERROR:" << LMS_GetLastErrorMessage();
    if (device != NULL)
        LMS_Close(device);
    cout << "Error when connecting" << endl; 
    exit(-1);
}

int main(int argc, char** argv)
{
    //Find devices
    int n;
	int intvar;
	
    lms_info_str_t list[8]; //should be large enough to hold all detected devices
    if ((n = LMS_GetDeviceList(list)) < 0) //NULL can be passed to only get number of devices
        error();

    cout << "Devices found: " << n << endl; //print number of devices
    if (n < 1) return -1;
	
	
	if ( argc == 1 ) {
                cout << "Argument should exist." << n << endl; 
		        cout << "Add argument 0 for Ch.A; 1 for Ch.B." << n << endl; 
		        return -1;
    }
	
	
	
	if (sscanf (argv[1], "%i", &intvar) != 1) {
          cout << "error - not an integer";
		  return -1;
    }
	
	int chA=1; //default
    if  (intvar==1) chA=0;
	
    
    //open the first device
    if (LMS_Open(&device, list[0], NULL))
        error();
    cout << "Device opened" << endl;
    
    //Initialize device with default configuration
    //Do not use if you want to keep existing configuration
    //Use LMS_LoadConfig(device, "/path/to/file.ini") to load config from INI
    //if (LMS_Init(device) != 0)
    //    error();
	
   CFRcomm *  cfr = new CFRcomm;
   cfr->Connect(device);
	
   cfr->SelCH_A(chA);
	
   cfr->BypassCFR(0);
   cfr->SetCFRFilterOrder(39);
   cfr->SetCFRThreshold(0.70); 

   DPDcomm *  dpd = new DPDcomm;
   dpd->QADPD_N=4;
   dpd->QADPD_M=2;
   dpd->QADPD_M2=0;
   dpd->QADPD_ND=47;
   dpd->QADPD_AM=14;
   dpd->QADPD_SKIP=100;
   dpd->QADPD_GAIN=1.0;
   dpd->QADPD_LAMBDA=0.9998;
   dpd-> QADPD_YPFPGA=true;
   dpd->QADPD_UPDATE=15000;
   dpd->QADPD_ENDC=1;
   dpd->QADPD_ENKONJ=1;
   dpd->samplesReceived=16384; 
   dpd->range=16.0;
   dpd->chA=chA;
   dpd->ind=0;
   

    dpd->Init();
    dpd->Connect(device);
	dpd->SelectSource(chA);
	
    cout << "[INFO] Device connected" << endl;
    dpd->CalibrateND();
    dpd->CalibrateGain();	
	dpd->QADPD_ND++;

    dpd->Start();
    
    for (int i=0; i<=2; i++) {
      dpd->Readdata_qpcie();
      dpd->Train();
      dpd->Send_coef();
    }

   
    dpd->End();
    

    //Close device
    LMS_Close(device);

    return 0;
}
